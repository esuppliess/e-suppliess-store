import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface CartItem {
  product: {
    id: string;
    title: string;
    price: number;
    images: string[];
  };
  quantity: number;
  selectedSize: string;
  deliveryOption: string;
}

interface CheckoutRequest {
  items: CartItem[];
  deliveryOption: string;
  customerEmail?: string;
}

const logStep = (step: string, details?: unknown) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-CHECKOUT] ${step}${detailsStr}`);
};

const RESERVATION_TTL_MINUTES = 35;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  let tempSessionId: string | null = null;

  try {
    logStep("Function started");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const { items, deliveryOption, customerEmail }: CheckoutRequest = await req.json();
    logStep("Request parsed", { itemCount: items?.length, deliveryOption });

    if (!items || items.length === 0) {
      throw new Error("No items in cart");
    }

    // Enforce email requirement server-side (prevents anonymous abuse)
    if (!customerEmail || typeof customerEmail !== 'string' || !customerEmail.includes('@')) {
      return new Response(JSON.stringify({ error: "A valid email address is required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // ── Clean up expired reservations before checking stock ──
    await supabaseAdmin.rpc("cleanup_expired_reservations");
    logStep("Expired reservations cleaned up");

    // ── Server-side inventory validation ──
    // Fetch authoritative prices and stock from database
    const productIds = [...new Set(items.map(i => i.product.id))];
    const { data: products, error: productsError } = await supabaseAdmin
      .from("products")
      .select("id, title, price, sizes, images, is_active")
      .in("id", productIds);

    if (productsError) throw new Error(`Failed to fetch products: ${productsError.message}`);

    const productMap = new Map(products?.map(p => [p.id, p]) || []);
    const stockErrors: string[] = [];
    const validatedItems: Array<CartItem & { serverPrice: number }> = [];

    for (const item of items) {
      const dbProduct = productMap.get(item.product.id);
      if (!dbProduct) {
        stockErrors.push(`${item.product.title} is no longer available.`);
        continue;
      }
      if (!dbProduct.is_active) {
        stockErrors.push(`${dbProduct.title} is no longer available.`);
        continue;
      }

      // Use server-side price (prevent price manipulation)
      const serverPrice = Number(dbProduct.price);

      // Check stock via atomic function (accounts for existing reservations)
      const { data: availableStock, error: stockError } = await supabaseAdmin
        .rpc("get_available_stock", { p_product_id: item.product.id, p_size: item.selectedSize });

      if (stockError) {
        logStep("Stock check error", { error: stockError.message });
        stockErrors.push(`Could not verify stock for ${dbProduct.title} (${item.selectedSize}).`);
        continue;
      }

      if (availableStock < item.quantity) {
        if (availableStock === 0) {
          stockErrors.push(`${dbProduct.title} / Size ${item.selectedSize} is sold out.`);
        } else {
          stockErrors.push(`Only ${availableStock} left for ${dbProduct.title} / Size ${item.selectedSize}.`);
        }
        continue;
      }

      validatedItems.push({
        ...item,
        product: {
          ...item.product,
          price: serverPrice,
          images: dbProduct.images || [],
        },
        serverPrice,
      });
    }

    if (stockErrors.length > 0) {
      return new Response(JSON.stringify({
        error: "inventory_error",
        message: "Some items in your cart have stock issues.",
        details: stockErrors,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 409,
      });
    }

    // ── Create temporary Stripe session ID for reservations ──
    // We'll create reservations first, then the Stripe session
    tempSessionId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + RESERVATION_TTL_MINUTES * 60 * 1000).toISOString();

    // ── Atomically reserve inventory for each variant ──
    for (const item of validatedItems) {
      const { data: reserved, error: reserveError } = await supabaseAdmin
        .rpc("reserve_inventory", {
          p_product_id: item.product.id,
          p_size: item.selectedSize,
          p_quantity: item.quantity,
          p_stripe_session_id: tempSessionId,
          p_expires_at: expiresAt,
        });

      if (reserveError || !reserved) {
        // Release any reservations we already made
        await supabaseAdmin.rpc("release_reservation", { p_stripe_session_id: tempSessionId });
        logStep("Reservation failed", { productId: item.product.id, size: item.selectedSize });
        return new Response(JSON.stringify({
          error: "inventory_error",
          message: `${item.product.title} / Size ${item.selectedSize} just sold out. Please update your cart.`,
          details: [`${item.product.title} / Size ${item.selectedSize} is no longer available in the requested quantity.`],
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 409,
        });
      }
    }

    logStep("All inventory reserved", { tempSessionId });

    // ── Resolve customer ──
    let userEmail: string | undefined = customerEmail;
    const authHeader = req.headers.get("Authorization");

    if (authHeader) {
      const supabaseClient = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_ANON_KEY") ?? ""
      );
      const token = authHeader.replace("Bearer ", "");
      const { data } = await supabaseClient.auth.getUser(token);
      if (data.user?.email) {
        userEmail = data.user.email;
      }
    }

    let customerId: string | undefined;
    if (userEmail) {
      const customers = await stripe.customers.list({ email: userEmail, limit: 1 });
      if (customers.data.length > 0) {
        customerId = customers.data[0].id;
      }
    }

    // ── Create Stripe line items using server-side prices ──
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = validatedItems.map((item) => {
      // Get available stock for max quantity hint
      const sizeData = productMap.get(item.product.id)?.sizes as Array<{ size: string; quantity: number }> | null;
      const sizeStock = sizeData?.find(s => s.size === item.selectedSize)?.quantity || item.quantity;
      const maxQty = Math.min(sizeStock, 10);

      const lineItem: Stripe.Checkout.SessionCreateParams.LineItem = {
        price_data: {
          currency: "cad",
          product_data: {
            name: item.product.title,
            description: `Size: ${item.selectedSize}`,
            images: item.product.images?.length > 0 ? [item.product.images[0]] : undefined,
            metadata: {
              product_id: item.product.id,
              size: item.selectedSize,
            },
          },
          unit_amount: Math.round(item.serverPrice * 100),
        },
        quantity: item.quantity,
      };

      // Only enable adjustable quantity if max > 1 (Stripe requires min < max)
      if (maxQty > 1) {
        lineItem.adjustable_quantity = {
          enabled: true,
          minimum: 1,
          maximum: maxQty,
        };
      }

      return lineItem;
    });

    // ── Shipping options ──
    const shippingOptions: Stripe.Checkout.SessionCreateParams.ShippingOption[] = [];

    if (deliveryOption === "gta-meetup") {
      shippingOptions.push({
        shipping_rate_data: {
          type: "fixed_amount",
          fixed_amount: { amount: 0, currency: "cad" },
          display_name: "Toronto/GTA Meetup",
          delivery_estimate: {
            minimum: { unit: "business_day", value: 1 },
            maximum: { unit: "business_day", value: 3 },
          },
        },
      });
    } else if (deliveryOption === "canada-shipping") {
      shippingOptions.push({
        shipping_rate_data: {
          type: "fixed_amount",
          fixed_amount: { amount: 1500, currency: "cad" },
          display_name: "Canada Shipping",
          delivery_estimate: {
            minimum: { unit: "business_day", value: 3 },
            maximum: { unit: "business_day", value: 7 },
          },
        },
      });
    } else if (deliveryOption === "worldwide-agent") {
      shippingOptions.push({
        shipping_rate_data: {
          type: "fixed_amount",
          fixed_amount: { amount: 5000, currency: "cad" },
          display_name: "Worldwide via Agent",
          delivery_estimate: {
            minimum: { unit: "business_day", value: 7 },
            maximum: { unit: "business_day", value: 21 },
          },
        },
      });
    }

    const origin = req.headers.get("origin") || "https://esupplies.lovable.app";

    const sessionParams: Stripe.Checkout.SessionCreateParams = {
      mode: "payment",
      line_items: lineItems,
      success_url: `${origin}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/checkout`,
      payment_method_types: ["card"],
      payment_intent_data: {
        receipt_email: userEmail,
      },
      billing_address_collection: "required",
      shipping_address_collection: deliveryOption !== "gta-meetup" ? {
        allowed_countries: deliveryOption === "canada-shipping" ? ["CA"] : ["CA", "US", "GB", "AU", "DE", "FR", "JP", "CN", "HK", "SG", "KR"],
      } : undefined,
      shipping_options: shippingOptions.length > 0 ? shippingOptions : undefined,
      expires_at: Math.floor(Date.now() / 1000) + RESERVATION_TTL_MINUTES * 60,
      metadata: {
        delivery_option: deliveryOption,
        reservation_id: tempSessionId,
        items_json: JSON.stringify(validatedItems.map(i => ({
          product_id: i.product.id,
          title: i.product.title,
          size: i.selectedSize,
          quantity: i.quantity,
          price: i.serverPrice,
        }))),
      },
    };

    if (customerId) {
      sessionParams.customer = customerId;
    } else if (userEmail) {
      sessionParams.customer_email = userEmail;
    }

    const session = await stripe.checkout.sessions.create(sessionParams);
    logStep("Checkout session created", { sessionId: session.id });

    // Update reservations with actual Stripe session ID
    await supabaseAdmin
      .from("inventory_reservations")
      .update({ stripe_session_id: session.id })
      .eq("stripe_session_id", tempSessionId);

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const rawMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: rawMessage });

    // Release any reservations that were created before the error
    if (tempSessionId) {
      try {
        const supabaseAdmin = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
          { auth: { persistSession: false } }
        );
        await supabaseAdmin.rpc("release_reservation", { p_stripe_session_id: tempSessionId });
        logStep("Released orphaned reservations", { tempSessionId });
      } catch (_) { /* ignore cleanup errors */ }
    }

    // Sanitize: never expose secrets or internal paths
    const isSafe = !rawMessage.includes("sk_") && !rawMessage.includes("whsec_");
    const safeMessage = isSafe ? rawMessage : "An internal error occurred while creating the checkout session.";

    return new Response(JSON.stringify({
      error: safeMessage,
      details: isSafe ? rawMessage : "Contact support if this persists.",
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
