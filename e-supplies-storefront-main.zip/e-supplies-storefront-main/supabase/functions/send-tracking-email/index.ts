import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const logStep = (step: string, details?: unknown) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[SEND-TRACKING-EMAIL] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Verify caller is admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    if (authError || !user) throw new Error("Unauthorized");

    // Check admin role
    const { data: isAdmin } = await supabaseAdmin.rpc("has_role", {
      _user_id: user.id,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden: admin only");

    const { orderId, trackingNumber } = await req.json();
    if (!orderId || !trackingNumber) throw new Error("orderId and trackingNumber required");

    logStep("Processing", { orderId, trackingNumber });

    // Get order details
    const { data: order, error: orderError } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("id", orderId)
      .single();

    if (orderError || !order) throw new Error("Order not found");

    const items = Array.isArray(order.items) ? order.items : [];
    const customerName = order.customer_name || "Customer";
    const customerEmail = order.customer_email;

    // Build items HTML
    const itemsHtml = items.map((item: Record<string, unknown>) => `
      <tr>
        <td style="padding: 12px 0; border-bottom: 1px solid #e5e5e5;">
          <strong>${item.title || 'Product'}</strong><br/>
          <span style="color: #666; font-size: 13px;">Size: ${item.size || 'N/A'} · Qty: ${item.quantity || 1}</span>
        </td>
        <td style="padding: 12px 0; border-bottom: 1px solid #e5e5e5; text-align: right; font-weight: 600;">
          $${Number(item.price || 0).toFixed(2)}
        </td>
      </tr>
    `).join('');

    const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"/></head>
    <body style="margin:0; padding:0; background:#f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
      <div style="max-width:560px; margin:0 auto; padding:40px 20px;">
        <div style="background:#000; padding:24px; text-align:center; border-radius:12px 12px 0 0;">
          <h1 style="color:#fff; margin:0; font-size:20px; letter-spacing:2px;">E SUPPLIES</h1>
        </div>
        <div style="background:#fff; padding:32px 24px; border-radius:0 0 12px 12px;">
          <h2 style="margin:0 0 8px; font-size:22px;">Your Order Has Shipped! 📦</h2>
          <p style="color:#666; margin:0 0 24px; font-size:15px;">Hey ${customerName}, your order is on its way.</p>
          
          <div style="background:#f9f9f9; border-radius:8px; padding:16px; margin-bottom:24px;">
            <p style="margin:0 0 4px; font-size:13px; color:#666; text-transform:uppercase; letter-spacing:1px;">Tracking Number</p>
            <p style="margin:0; font-size:18px; font-weight:700; font-family:monospace; letter-spacing:1px;">${trackingNumber}</p>
          </div>

          <h3 style="margin:0 0 12px; font-size:15px; text-transform:uppercase; letter-spacing:1px; color:#999;">Order Summary</h3>
          <table style="width:100%; border-collapse:collapse;">
            ${itemsHtml}
            <tr>
              <td style="padding:12px 0; font-weight:700;">Total</td>
              <td style="padding:12px 0; text-align:right; font-weight:700;">$${Number(order.total).toFixed(2)}</td>
            </tr>
          </table>

          <hr style="border:none; border-top:1px solid #e5e5e5; margin:24px 0;"/>
          <p style="color:#999; font-size:12px; text-align:center; margin:0;">
            If you have any questions, reach out to us on Instagram 
            <a href="https://instagram.com/e_suppliess" style="color:#000;">@e_suppliess</a>
          </p>
        </div>
      </div>
    </body>
    </html>`;

    // Send via Resend
    const resendKey = Deno.env.get("RESEND_API_KEY");
    if (!resendKey) {
      logStep("RESEND_API_KEY not configured, skipping email");
      return new Response(JSON.stringify({ success: true, emailSent: false, reason: "RESEND_API_KEY not configured" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const emailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: Deno.env.get("RESEND_FROM_EMAIL") || "E Supplies <onboarding@resend.dev>",
        to: [customerEmail],
        subject: `Your E Supplies order has shipped! 📦`,
        html: emailHtml,
      }),
    });

    const emailResult = await emailRes.json();
    logStep("Email result", { status: emailRes.status, result: emailResult });

    if (!emailRes.ok) {
      logStep("Email send failed", emailResult);
      return new Response(JSON.stringify({ success: true, emailSent: false, error: emailResult }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    return new Response(JSON.stringify({ success: true, emailSent: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
