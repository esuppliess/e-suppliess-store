import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

serve(async (req) => {
  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Count active expired reservations before cleanup
    const { count } = await supabaseAdmin
      .from("inventory_reservations")
      .select("*", { count: "exact", head: true })
      .eq("status", "active")
      .lte("expires_at", new Date().toISOString());

    // Run cleanup
    await supabaseAdmin.rpc("cleanup_expired_reservations");

    const released = count ?? 0;
    console.log(`[CLEANUP-RESERVATIONS] Released ${released} expired reservation(s)`);

    return new Response(JSON.stringify({ released }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error("[CLEANUP-RESERVATIONS] ERROR:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      headers: { "Content-Type": "application/json" },
      status: 500,
    });
  }
});
