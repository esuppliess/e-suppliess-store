import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const logStep = (step: string, details?: unknown) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[STRIPE-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req) => {
  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    if (!webhookSecret) throw new Error("STRIPE_WEBHOOK_SECRET is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Verify webhook signature
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");
    if (!signature) throw new Error("No stripe-signature header");

    let event: Stripe.Event;
    try {
      event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
    } catch (err) {
      logStep("Webhook signature verification failed", { error: String(err) });
      return new Response(JSON.stringify({ error: "Invalid signature" }), { status: 400 });
    }

    logStep("Event received", { type: event.type, id: event.id });

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const reservationId = session.metadata?.reservation_id;

      if (session.payment_status === "paid") {
        logStep("Payment successful, finalizing reservation", { reservationId });

        // Finalize reservation (permanently decrement stock)
        if (reservationId) {
          // The reservation was stored under the Stripe session ID (updated from temp)
          const { error: finalizeError } = await supabaseAdmin.rpc("finalize_reservation", {
            p_stripe_session_id: session.id,
          });
          if (finalizeError) {
            logStep("Finalize error", { error: finalizeError.message });
          }
        }

        // Create order
        const itemsJson = session.metadata?.items_json;
        const items = itemsJson ? JSON.parse(itemsJson) : [];
        const deliveryOption = session.metadata?.delivery_option || "canada-shipping";
        const customerEmail = session.customer_email ||
          (typeof session.customer_details === 'object' && session.customer_details?.email) || "";
        const customerName = session.customer_details?.name || null;
        const shippingAddress = session.shipping_details?.address || session.customer_details?.address || null;

        // Check if order already exists
        const { data: existingOrder } = await supabaseAdmin
          .from("orders")
          .select("id")
          .eq("stripe_session_id", session.id)
          .single();

        if (!existingOrder) {
          const { error: orderError } = await supabaseAdmin
            .from("orders")
            .insert({
              stripe_session_id: session.id,
              customer_email: customerEmail,
              customer_name: customerName,
              items,
              total: (session.amount_total || 0) / 100,
              delivery_option: deliveryOption as "gta-meetup" | "canada-shipping" | "worldwide-agent",
              shipping_address: shippingAddress,
              status: "pending",
            });
          if (orderError) {
            logStep("Order creation error", { error: orderError.message });
          } else {
            logStep("Order created successfully");
          }
        }
      }
    } else if (event.type === "checkout.session.expired" || event.type === "checkout.session.async_payment_failed") {
      const session = event.data.object as Stripe.Checkout.Session;
      logStep("Session expired/failed, releasing reservation", { sessionId: session.id });

      // Release the reservation so stock becomes available again
      const { error: releaseError } = await supabaseAdmin.rpc("release_reservation", {
        p_stripe_session_id: session.id,
      });
      if (releaseError) {
        logStep("Release error", { error: releaseError.message });
      }
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { "Content-Type": "application/json" },
      status: 500,
    });
  }
});
