

# E Supplies — Premium Reselling E-commerce Store

## Overview
A mobile-first, premium e-commerce website for **E Supplies**, focused on selling physical products (stock) with a secondary Vendors page for digital product upsells via Beacons. The design follows the DRMERS CLUB aesthetic: minimal, product-forward, high-contrast black/white with clean typography.

---

## Phase 1: MVP Core (Product-First)

### 1. Design System & Foundation
- **Color scheme**: Pure black (#000000) background, white (#FFFFFF) text/borders, gray (#BDBDBD) secondary text
- **Typography**: Inter font with strong hierarchy — uppercase bold headings, clean 13-15px body text
- **UI Kit**: Rounded corners (14-18px), subtle hover animations, premium feel
- **S Supplies logo** placement in header (center) and footer (subtle)

### 2. Navigation (Sticky Header)
- **Desktop**: SHOP (left) | Logo/Home (center) | Search + Cart icons (right)
- **Mobile**: Hamburger menu with full navigation
- **Menu items**: Home, Shop, Vendors, Vouches, FAQs, Contact
- **Sticky behavior** on scroll with backdrop blur effect

### 3. Home Page (DRMERS Style)
- **Hero section**: 3-panel editorial layout with placeholders
  - Tagline: "Curated stock. Premium sourcing. Built for serious buyers."
  - CTAs: "Shop Stock" (primary) + "View Proof" (secondary)
- **Product grid tabs**: NEW ARRIVALS / BEST SELLERS with sample products
- **Featured Drops section**: Highlight category with lifestyle imagery
- **Shop the Look carousel**: Horizontal scroll with lifestyle placeholders
- **Delivery strip**: "Toronto/GTA meetup • Canada shipping • Worldwide via agent"
- **Social links footer**: Instagram, TikTok (x2), Discord icons

### 4. Shop Page (Collection)
- **Grid layout**: 4-column desktop / 2-column mobile
- **Filters**: Category, Brand, Price range, Condition, Size
- **Product cards**:
  - Badge system (NEW IN / BACK IN STOCK / SOLD OUT)
  - Hover image swap on desktop
  - Title + USD price display
  - Quick view swatches (optional)
- **Categories**: Hoodies, Jackets, Shoes, Bags, Scarves, Fragrance, Electronics, Accessories

### 5. Product Detail Page
- **Desktop layout**: Two-column (left: vertical image grid, right: details)
- **Mobile**: Stacked layout with image carousel
- **Product info**: Title, price (USD), condition badge, size selector
- **Delivery options**: Toronto/GTA Meetup, Canada Shipping, Worldwide via Agent
- **Accordions**: Product Details, Shipping Information, Ask a Question
- **Sticky mobile CTA bar**: Add to Cart always visible while scrolling
- **Related products section**: "You may also like"

### 6. Cart
- Slide-out cart drawer from right side
- Line items with image, title, size, quantity, price
- Quantity adjusters and remove option
- Subtotal + checkout button
- Empty cart state with "Continue Shopping" CTA

### 7. Checkout (Stripe Integration)
- **Enable Stripe payments** for processing
- Collect: Email, shipping address (if shipping selected)
- Delivery option confirmation (Meetup shows pickup instructions)
- Order summary with line items
- Secure payment via Stripe
- Currency: USD

### 8. Order Confirmation
- Success page with order number and details
- Email confirmation sent to customer
- If GTA Meetup: Display pickup instructions prominently
- Social share + "Continue Shopping" CTA

---

## Phase 2: Secondary Pages

### 9. Vendors Page (High-Conversion Layout)
- **Sticky HeroStatsBar**: "10,247 happy customers" | "Rated 4.98/5" | "54 live viewers" | Countdown timer
- **Headline section**: High-contrast with optional gold (#D1B037) accent word
- **Vendor product grid** using VendorProductCard:
  - Tilted "BEST DEAL" badge for bundle
  - Price anchoring: strikethrough + sale price
  - "DETAILS +" button → modal with bullets, delivery method, disclaimers
  - "GET ACCESS" gold CTA → links to https://beacons.ai/e_suppliess
- **Products listed**: Clothing Vendor, Shoe Vendor, AirPods & Electronics, Cologne, Bag & Purse, Full Bundle

### 10. Vouches / Proof Page
- Grid of proof tiles with placeholders
- Customer feedback cards
- Privacy disclaimer
- CTA back to Shop

### 11. FAQs Page
- Accordion sections: Orders, Delivery, Payments, Authenticity, Support
- Search functionality (optional)

### 12. Contact Page
- Form: Name, Email, Order # (optional), Message
- Business email placeholder
- Social icons

### 13. Shipping & Delivery Page
- Toronto/GTA meetup details
- Canada shipping timelines
- Worldwide via agent info
- Tracking and delay policies

### 14. Policies Pages
- Terms of Service
- Privacy Policy
- Refund Policy (physical: defined policy, digital: no refunds)
- Compliance disclaimer

---

## Phase 3: Backend & Admin

### 15. Database (Lovable Cloud)
**Tables to create:**
- `products`: id, type, title, description, price_usd, category, brand, condition, sizes, images, inventory_count, is_active
- `orders`: id, stripe_session_id, customer_email, status, total_usd, items, delivery_option, shipping_address, created_at
- `customers`: id, email, name, created_at
- `email_subscribers`: id, email, created_at

### 16. Admin Dashboard (/admin)
- **Password-protected access** (single admin)
- **Products management**: Add/edit products, upload images, set sizes/inventory/visibility
- **Orders view**: List orders, update statuses, view customer details
- **Low-stock indicators** for inventory management
- **Simple analytics**: Total orders, revenue, popular products

---

## Phase 4: Polish & SEO

### 17. Performance & SEO
- Lazy loading for images
- Meta tags and OpenGraph for social sharing
- Clean URLs: `/shop/shoes/product-name`
- Mobile-first responsive design throughout

### 18. Sample Data
- Seed database with 15-20 sample products across categories
- Placeholder lifestyle images matching DRMERS aesthetic
- Realistic pricing in USD

---

## Social Links (Hardcoded)
- Instagram: https://instagram.com/e_suppliess
- TikTok: https://tiktok.com/@e_suppliess
- TikTok2: https://tiktok.com/@e_suppliess2
- Beacons: https://beacons.ai/e_suppliess
- Discord: [PLACEHOLDER]

---

## Summary
This plan delivers a **premium, conversion-focused e-commerce experience** that prioritizes the physical product shopping journey. The DRMERS-inspired design creates a high-end feel, while the mobile-first approach and sticky CTAs optimize for conversions. The Vendors page uses the high-conversion blueprint with gold accents, linking out to Beacons for digital products.

